/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogoteste;

import java.util.*;
import javax.swing.*;
/**
 *
 * @author napster
 */
public class JogoTeste {
    
    
    public static void main(String[] args) {
        
       
        String RespostaAnimal = null;
        int Opmenu = 0 ;          
        
        Animal bicho = new  Animal();        
        List ListaAnimal = new ArrayList();
        
        JOptionPane.showMessageDialog(null, "Matheus Freire 44 9 9860-4634 \n www.semprebomtecnologia.com.br  \n MGA- Gestão Publica ");             
            
        if (JOptionPane.showConfirmDialog(null, "Bora Jogar  ?", "MGA- Gestão Publica ",  JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)  {
            
            do {
            
            JOptionPane.showMessageDialog(null, "Pense em um Animal? Você pensou...");             
            RespostaAnimal =  JOptionPane.showInputDialog(null, "Qual o Nome do Animal que você Pensou, quero Advinhar ???  ");
            //ListaAnimal.add(JOptionPane.showInputDialog(null, "Qual o Nome do Animal que você Pensou, quero Advinhar ???  ") );
            
            if (JOptionPane.showConfirmDialog(null,"O Animal é do tipo Aquatico? "," Qual o Tipo de Animal",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                //RacaAnimalAquatica
                for (String s : bicho.racaAnimalAquatico){
                    if (s.equals(RespostaAnimal)){
                        JOptionPane.showMessageDialog(null, "Advinhei o Aninal !!! "+ RespostaAnimal);
                        break;
                    } else {JOptionPane.showMessageDialog(null, "Não Advinhei o Animal, qual você pensou... \n  OK..."); break; }
                } 
            } else {
                //racaAnimal
                for (String s : bicho.racaAnimal){
                    if (s.equals(RespostaAnimal)){                        
                        JOptionPane.showMessageDialog(null, "Advinhei o Aninal !!! "+ RespostaAnimal);                        
                        break;
                    } else { JOptionPane.showMessageDialog(null, "Não Advinhei o Animal, qual você pensou... \n  OK..."); break; }
                }
                 
            }
            
            //ListaAnimal.add(RespostaAnimal);                
            
            Opmenu =  (JOptionPane.showConfirmDialog(null , "vamos tentar  denovo ? "," MGA- Gestão Publica",JOptionPane.YES_NO_OPTION , JOptionPane.QUESTION_MESSAGE) );
        
            }while (Opmenu != 1 );
        
        }else { JOptionPane.showMessageDialog(null, "Obrigado por Jogar..."); System.exit(0); }

            
        
       
        
        

        
//        
//        for (int i = 0; i < ListaAnimal.size() ; i++) {
//                String x = ListaAnimal.get(i).toString();
//                 x = "-- " +  ListaAnimal.get(i).toString();
//
//                //x = x +" " + cliente.getNomeCliente();
//                System.out.println("Digitados foram !!!  :"+ x );
//        }
    }

   


    
}



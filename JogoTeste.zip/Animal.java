/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogoteste;


import java.util.*;
import javax.swing.*;
/**
 *
 * @author napster
 */
public class Animal {
    public  String[] racaAnimal =  {"boi","cavalo", "cachoro", "gato"};
    public  String[] racaAnimalAquatico = {"jacare","tubarao", "anta", "sapo"};   
   
    public void ExibeAnimalAquatico() {           
        for (String s : racaAnimalAquatico){
            System.out.println(s);
        }        
    }

    public void setRacaAnimal(String[] racaAnimal) {
        this.racaAnimal = racaAnimal;
    }

    public void setRacaAnimalAquatico(String[] racaAnimalAquatico) {
        this.racaAnimalAquatico = racaAnimalAquatico;
    }

    public void ExibeAnimal() {           
        for (String s : racaAnimal){
            System.out.println(s);
        }        
    }

    

}
